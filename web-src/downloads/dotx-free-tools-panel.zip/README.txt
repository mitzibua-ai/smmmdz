# dotx Free Tools Panel

1. Extract this ZIP anywhere.
2. Run `panel.py` with Python 3.12, or use `run-free-tools-panel.bat` from the project root.
3. Click **Download All** or select tools and download.
4. When finished, click the red **Clean Installed Tools** button to remove everything the panel installed.

Install folder: `%LOCALAPPDATA%\DotXFreeTools\`

Tool ZIP files are served from: https://dotx.store/downloads/free-tools/
