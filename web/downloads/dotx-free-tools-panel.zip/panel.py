"""dotx Free Tools — branded all-in-one panel with Discord identity and in-use watch."""
from __future__ import annotations

import base64
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

import tkinter as tk
from tkinter import messagebox, ttk

ROOT = Path(__file__).resolve().parent
CATALOG_PATH = ROOT / "catalog.json"
DEFAULT_BASE_URL = "https://dotx.store/downloads/free-tools/"
DOTX_CONFIG_MARKER = b"DOTXCONFIG"

# Dot X Free Tools — dark shell, red edges, white text
BG = "#0a0a0c"
BG_CARD = "#121216"
BG_HOVER = "#18181e"
BG_BADGE = "#1a0f10"
TEXT = "#ffffff"
MUTED = "#a1a1aa"
ACCENT = "#d40000"
ACCENT_SOFT = "#2a1012"
TEAL = "#d40000"
TEAL_DIM = "#ff4d4d"
WARN = "#fb923c"
WARN_SOFT = "#fdba74"
CLEAN_RED = "#d40000"
CLEAN_RED_HOVER = "#ef4444"
IN_USE = "#fb923c"
BORDER = "#d40000"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_ROW = ("Segoe UI", 13, "bold")
FONT_DESC = ("Segoe UI", 10)
FONT_TITLE = ("Segoe UI", 16, "bold")
FONT_LOGO = ("Segoe UI", 22, "bold")
FONT_SMALL = ("Segoe UI", 9)
FONT_MONO = ("Consolas", 9)
ROW_LINE = "#26262e"


def resource_path(name: str) -> Path:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        bundled = Path(sys._MEIPASS) / name
        if bundled.exists():
            return bundled
    return ROOT / name


def app_data_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(base) / "DotXFreeTools"


def manifest_path() -> Path:
    return app_data_dir() / "manifest.json"


def load_catalog() -> dict:
    path = resource_path("catalog.json")
    if path.is_file():
        return json.loads(path.read_text(encoding="utf-8"))
    if CATALOG_PATH.is_file():
        return json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    return {"tools": [], "panelVersion": "2.0.0", "signature": "Free Tools"}


def load_embedded_config() -> dict:
    if getattr(sys, "frozen", False):
        try:
            data = Path(sys.executable).read_bytes()
            idx = data.rfind(DOTX_CONFIG_MARKER)
            if idx != -1:
                payload = data[idx + len(DOTX_CONFIG_MARKER) :].decode("utf-8")
                config = json.loads(payload)
                if isinstance(config, dict):
                    return config
        except (UnicodeDecodeError, json.JSONDecodeError, OSError):
            pass

    for candidate in (
        ROOT / "dotx.config.json",
        app_data_dir() / "dotx.config.json",
        Path(sys.executable).resolve().parent / "dotx.config.json" if getattr(sys, "frozen", False) else None,
    ):
        if candidate and candidate.is_file():
            try:
                data = json.loads(candidate.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    return data
            except (json.JSONDecodeError, OSError):
                pass
    return {}


def load_tool_branding() -> dict:
    branding = load_embedded_config().get("branding") or {}
    if not isinstance(branding, dict):
        branding = {}
    return {
        "showDiscordAvatar": branding.get("showDiscordAvatar", True) is not False,
        "username": str(branding.get("username") or "").strip()[:64],
        "discordId": str(branding.get("discordId") or "").strip(),
        "avatarUrl": str(branding.get("avatarUrl") or "").strip()[:500],
        "customImage": branding.get("customImage") or None,
    }


def load_manifest() -> dict:
    path = manifest_path()
    if not path.is_file():
        return {"installed": {}}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {"installed": {}}


def save_manifest(data: dict) -> None:
    path = manifest_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def download_file(url: str, dest: Path, on_progress=None) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/126.0.0.0 Safari/537.36"
            ),
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
        },
    )
    with urllib.request.urlopen(req, timeout=300) as resp:
        total = int(resp.headers.get("Content-Length") or 0)
        chunk_size = 65536
        downloaded = 0
        with dest.open("wb") as f:
            while True:
                chunk = resp.read(chunk_size)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                if on_progress and total:
                    on_progress(downloaded / total)


def extract_zip(zip_path: Path, target: Path) -> list[str]:
    target.mkdir(parents=True, exist_ok=True)
    paths: list[str] = []
    with zipfile.ZipFile(zip_path, "r") as zf:
        for member in zf.namelist():
            zf.extract(member, target)
            paths.append(str((target / member).resolve()))
    return paths


def running_process_names() -> set[str]:
    names: set[str] = set()
    if sys.platform != "win32":
        return names
    try:
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        out = subprocess.check_output(
            ["tasklist", "/FO", "CSV", "/NH"],
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=8,
            creationflags=creationflags,
        )
        for line in out.splitlines():
            line = line.strip()
            if not line.startswith('"'):
                continue
            # "Image Name","PID","Session Name","Session#","Mem Usage"
            parts = line.split('","')
            if parts:
                names.add(parts[0].strip('"').lower())
    except (subprocess.SubprocessError, OSError):
        pass
    return names


def find_launchable(tool_dir: Path) -> Path | None:
    if not tool_dir.is_dir():
        return None
    exes = [p for p in tool_dir.rglob("*.exe") if p.is_file()]
    if not exes:
        return None
    # Prefer top-level / non-uninstaller names
    ranked = sorted(
        exes,
        key=lambda p: (
            "uninstall" in p.name.lower() or "setup" in p.name.lower(),
            len(p.parts),
            p.name.lower(),
        ),
    )
    return ranked[0]


class FreeToolsPanel(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.catalog = load_catalog()
        self.tools = self.catalog.get("tools", [])
        self.signature = str(self.catalog.get("signature") or "Free Tools")
        self.base_url = os.environ.get("DOTX_TOOLS_URL", DEFAULT_BASE_URL).rstrip("/") + "/"
        self.install_root = app_data_dir()
        self.manifest = load_manifest()
        self.branding = load_tool_branding()
        self._status_labels: dict[str, tk.Label] = {}
        self._use_labels: dict[str, tk.Label] = {}
        self._action_btns: dict[str, tk.Button] = {}
        self._row_bgs: dict[str, str] = {}
        self._in_use: set[str] = set()
        self._avatar_photo: tk.PhotoImage | None = None
        self._toast_after: str | None = None
        self.busy = False

        self.title(f"dotx — {self.signature}")
        self.geometry("980x720")
        self.minsize(840, 580)
        self.configure(bg=BG)

        try:
            icon = resource_path("assets/dotx.ico")
            if icon.is_file():
                self.iconbitmap(default=str(icon))
        except tk.TclError:
            pass

        self._build_ui()
        self._load_discord_badge()
        self._refresh_status()
        self.after(800, self._poll_in_use)

    def _build_ui(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(
            "DX.Horizontal.TProgressbar",
            troughcolor="#1c1c22",
            background=ACCENT,
            bordercolor="#1c1c22",
            lightcolor=ACCENT,
            darkcolor=ACCENT,
        )

        # Frame padx/pady must be a single int — tuples become Tcl "0 14" and crash
        self.header = tk.Frame(self, bg=BG_CARD, highlightbackground=BORDER, highlightthickness=2)
        self.header.pack(fill="x", padx=16, pady=(16, 10))

        brand = tk.Frame(self.header, bg=BG_CARD)
        brand.pack(side="left", padx=16, pady=14)
        logo_row = tk.Frame(brand, bg=BG_CARD)
        logo_row.pack(anchor="w")
        tk.Label(logo_row, text="dot", fg=TEXT, bg=BG_CARD, font=FONT_LOGO).pack(side="left")
        tk.Label(logo_row, text="x", fg=ACCENT, bg=BG_CARD, font=FONT_LOGO).pack(side="left")
        tk.Label(
            logo_row,
            text=f"  {self.signature}",
            fg=ACCENT,
            bg=BG_CARD,
            font=FONT_TITLE,
        ).pack(side="left", padx=(8, 0))

        self.discord_frame = tk.Frame(
            self.header, bg=ACCENT_SOFT, highlightbackground=BORDER, highlightthickness=1
        )
        self.discord_frame.pack(side="right", padx=14, pady=12)
        self.avatar_lbl = tk.Label(
            self.discord_frame, text="◆", fg=ACCENT, bg=ACCENT_SOFT, font=FONT_BOLD
        )
        self.avatar_lbl.pack(side="left", padx=(10, 8), pady=8)
        name_col = tk.Frame(self.discord_frame, bg=ACCENT_SOFT)
        name_col.pack(side="left", padx=(0, 4), pady=8)
        self.discord_name = tk.Label(
            name_col, text="Guest", fg=TEXT, bg=ACCENT_SOFT, font=FONT_BOLD, anchor="e"
        )
        self.discord_name.pack(anchor="e")
        self.discord_sub = tk.Label(
            name_col, text="No Discord stamp", fg=MUTED, bg=ACCENT_SOFT, font=FONT_SMALL, anchor="e"
        )
        self.discord_sub.pack(anchor="e")
        tk.Label(
            self.discord_frame,
            text=f"v{self.catalog.get('panelVersion', '2.0')}",
            fg=ACCENT,
            bg=ACCENT_SOFT,
            font=FONT_MONO,
        ).pack(side="left", padx=(10, 12), pady=8)

        self.toast = tk.Label(self, text="", fg="#ffffff", bg=IN_USE, font=FONT_BOLD)

        toolbar = tk.Frame(self, bg=BG)
        toolbar.pack(fill="x", padx=16, pady=(0, 8))

        self.btn_all = tk.Button(
            toolbar,
            text="Download All",
            command=self.download_all,
            bg=ACCENT,
            fg="#ffffff",
            activebackground=CLEAN_RED_HOVER,
            activeforeground="#ffffff",
            relief="flat",
            padx=16,
            pady=8,
            font=FONT_BOLD,
            cursor="hand2",
            bd=0,
        )
        self.btn_all.pack(side="left")

        self.btn_clean = tk.Button(
            toolbar,
            text="Clean Installed",
            command=self.clean_installed,
            bg="#111111",
            fg="#ffffff",
            activebackground="#333333",
            activeforeground="#ffffff",
            relief="flat",
            padx=14,
            pady=8,
            font=FONT_BOLD,
            cursor="hand2",
            bd=0,
        )
        self.btn_clean.pack(side="right")

        meta_row = tk.Frame(self, bg=BG)
        meta_row.pack(fill="x", padx=16, pady=(0, 8))
        self.in_use_summary = tk.Label(meta_row, text="In use: none", fg=MUTED, bg=BG, font=FONT_SMALL)
        self.in_use_summary.pack(side="left")
        tk.Label(
            meta_row, text=f"{len(self.tools)} tools in suite", fg=MUTED, bg=BG, font=FONT_SMALL
        ).pack(side="right")

        list_wrap = tk.Frame(self, bg=BG_CARD, highlightbackground=BORDER, highlightthickness=2)
        list_wrap.pack(fill="both", expand=True, padx=16, pady=(0, 8))

        canvas = tk.Canvas(list_wrap, bg=BG_CARD, highlightthickness=0)
        scroll = ttk.Scrollbar(list_wrap, orient="vertical", command=canvas.yview)
        self.list_frame = tk.Frame(canvas, bg=BG_CARD)
        self.list_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        self._list_window = canvas.create_window((0, 0), window=self.list_frame, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)

        def _on_canvas_configure(event: tk.Event) -> None:
            canvas.itemconfigure(self._list_window, width=max(event.width, 1))
            self._reflow_descriptions(max(event.width, 1))

        canvas.bind("<Configure>", _on_canvas_configure)

        def _on_mousewheel(event: tk.Event) -> None:
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        self._desc_labels: list[tk.Label] = []
        for i, tool in enumerate(self.tools):
            self._add_tool_row(self.list_frame, tool, i)

        progress_frame = tk.Frame(self, bg=BG)
        progress_frame.pack(fill="x", padx=16, pady=(0, 16))
        self.progress = ttk.Progressbar(
            progress_frame, mode="determinate", maximum=100, style="DX.Horizontal.TProgressbar"
        )
        self.progress.pack(fill="x")
        self.status = tk.Label(progress_frame, text="Ready.", fg=MUTED, bg=BG, font=FONT, anchor="w")
        self.status.pack(fill="x", pady=(8, 0))

    def _reflow_descriptions(self, list_width: int) -> None:
        # Leave room for the right-side Download button + padding
        wrap = max(280, list_width - 220)
        for lbl in getattr(self, "_desc_labels", []):
            try:
                lbl.configure(wraplength=wrap)
            except tk.TclError:
                pass

    def _add_tool_row(self, parent: tk.Frame, tool: dict, index: int) -> None:
        """Row format: title + description left, Download right (DotX theme)."""
        bg = BG_CARD
        self._row_bgs[tool["id"]] = bg

        block = tk.Frame(parent, bg=bg)
        block.pack(fill="x")

        row = tk.Frame(block, bg=bg)
        row.pack(fill="x", padx=22, pady=18)

        left = tk.Frame(row, bg=bg)
        left.pack(side="left", fill="both", expand=True, padx=(0, 16))

        title_row = tk.Frame(left, bg=bg)
        title_row.pack(fill="x")
        tk.Label(title_row, text=tool["name"], fg=TEXT, bg=bg, font=FONT_ROW, anchor="w").pack(
            side="left"
        )
        use_lbl = tk.Label(title_row, text="", fg=IN_USE, bg=bg, font=("Segoe UI", 8, "bold"))
        use_lbl.pack(side="left", padx=(10, 0))
        self._use_labels[tool["id"]] = use_lbl

        desc = tk.Label(
            left,
            text=tool.get("description", ""),
            fg=MUTED,
            bg=bg,
            font=FONT_DESC,
            wraplength=620,
            justify="left",
            anchor="w",
        )
        desc.pack(anchor="w", fill="x", pady=(8, 0))
        self._desc_labels.append(desc)

        status_lbl = tk.Label(left, text="", fg=MUTED, bg=bg, font=FONT_SMALL, anchor="w")
        status_lbl.pack(anchor="w", pady=(6, 0))
        self._status_labels[tool["id"]] = status_lbl

        right = tk.Frame(row, bg=bg)
        right.pack(side="right", padx=(8, 0))

        action_btn = tk.Button(
            right,
            text="Download",
            command=lambda tid=tool["id"]: self.download_one(tid),
            bg=ACCENT,
            fg="#ffffff",
            activebackground=CLEAN_RED_HOVER,
            activeforeground="#ffffff",
            relief="flat",
            padx=22,
            pady=10,
            font=FONT_BOLD,
            cursor="hand2",
            bd=0,
            width=10,
        )
        action_btn.pack(anchor="e")
        self._action_btns[tool["id"]] = action_btn

        # Subtle divider between rows (not a card — list format)
        if index < len(self.tools) - 1:
            tk.Frame(block, bg=ROW_LINE, height=1).pack(fill="x", padx=18)

    def _photo_from_bytes(self, data: bytes) -> tk.PhotoImage | None:
        try:
            return tk.PhotoImage(data=data)
        except tk.TclError:
            pass
        try:
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                tmp.write(data)
                tmp_path = tmp.name
            photo = tk.PhotoImage(file=tmp_path)
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            return photo
        except (tk.TclError, OSError):
            return None

    def _photo_from_url(self, url: str) -> tk.PhotoImage | None:
        if "cdn.discordapp.com" in url and ".webp" in url:
            url = url.replace(".webp", ".png")
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "DotXFreeTools/2.0"})
            with urllib.request.urlopen(req, timeout=12) as resp:
                data = resp.read()
            return self._photo_from_bytes(data)
        except (urllib.error.URLError, OSError, TimeoutError):
            return None

    def _photo_from_data_url(self, data_url: str) -> tk.PhotoImage | None:
        if not data_url or "," not in data_url:
            return None
        try:
            raw = base64.b64decode(data_url.split(",", 1)[1])
            return self._photo_from_bytes(raw)
        except (ValueError, OSError):
            return None

    def _fit_photo(self, photo: tk.PhotoImage, max_w: int, max_h: int) -> tk.PhotoImage:
        w, h = photo.width(), photo.height()
        if w <= max_w and h <= max_h:
            return photo
        factor = max(1, int(max(w / max_w, h / max_h)))
        return photo.subsample(factor, factor)

    def _load_discord_badge(self) -> None:
        name = self.branding.get("username") or "Guest"
        discord_id = self.branding.get("discordId") or ""
        self.discord_name.configure(text=name)
        if discord_id:
            self.discord_sub.configure(text=f"ID {discord_id}")
        elif name != "Guest":
            self.discord_sub.configure(text="Moderator")
        else:
            self.discord_sub.configure(text="Download from dashboard to stamp")

        photo = None
        custom = self.branding.get("customImage")
        if isinstance(custom, str) and custom.startswith("data:"):
            photo = self._photo_from_data_url(custom)
        if photo is None and self.branding.get("showDiscordAvatar"):
            avatar_url = str(self.branding.get("avatarUrl") or "")
            if avatar_url:
                photo = self._photo_from_url(avatar_url)
        if photo is not None:
            self._avatar_photo = self._fit_photo(photo, 36, 36)
            self.avatar_lbl.configure(image=self._avatar_photo, width=36, height=36, text="")
        else:
            self.avatar_lbl.configure(image="", text="◆", fg=ACCENT, font=FONT_BOLD)

    def _show_toast(self, message: str, ms: int = 4200) -> None:
        self.toast.configure(text=f"  {message}  ")
        self.toast.pack_forget()
        self.toast.pack(fill="x", after=self.header)
        if self._toast_after:
            try:
                self.after_cancel(self._toast_after)
            except tk.TclError:
                pass

        def hide() -> None:
            self.toast.pack_forget()
            self._toast_after = None

        self._toast_after = self.after(ms, hide)

    def _tool_process_names(self, tool: dict) -> set[str]:
        names = {str(n).lower() for n in tool.get("processNames") or []}
        installed = self.manifest.get("installed", {}).get(tool["id"])
        if installed:
            tool_dir = Path(installed.get("dir", self.install_root / tool["id"]))
            if tool_dir.is_dir():
                for exe in tool_dir.rglob("*.exe"):
                    names.add(exe.name.lower())
        return names

    def _poll_in_use(self) -> None:
        running = running_process_names()
        active: set[str] = set()
        newly: list[str] = []
        stopped: list[str] = []

        for tool in self.tools:
            tid = tool["id"]
            names = self._tool_process_names(tool)
            is_up = bool(names & running)
            was_up = tid in self._in_use
            if is_up:
                active.add(tid)
                if not was_up:
                    newly.append(tool["name"])
            elif was_up:
                stopped.append(tool["name"])

            use_lbl = self._use_labels.get(tid)
            if use_lbl:
                if is_up:
                    use_lbl.configure(text="● IN USE", fg=IN_USE)
                else:
                    use_lbl.configure(text="", fg=MUTED)

        self._in_use = active
        if active:
            labels = [t["name"] for t in self.tools if t["id"] in active]
            self.in_use_summary.configure(
                text="In use: " + ", ".join(labels[:4]) + ("…" if len(labels) > 4 else ""),
                fg=IN_USE,
            )
        else:
            self.in_use_summary.configure(text="In use: none", fg=MUTED)

        if newly:
            self._show_toast("IN USE — " + ", ".join(newly) + " is open (don't confuse live tools)")
        if stopped and not newly:
            self._show_toast("Closed — " + ", ".join(stopped), ms=2800)

        self.after(2500, self._poll_in_use)

    def _set_busy(self, busy: bool) -> None:
        self.busy = busy
        state = "disabled" if busy else "normal"
        self.btn_all.configure(state=state)
        self.btn_clean.configure(state=state)
        for btn in self._action_btns.values():
            btn.configure(state=state)

    def _set_status(self, text: str, pct: float | None = None) -> None:
        self.status.configure(text=text)
        if pct is not None:
            self.progress["value"] = max(0, min(100, pct * 100))

    def _refresh_status(self) -> None:
        installed = self.manifest.get("installed", {})
        for tool_id, lbl in self._status_labels.items():
            btn = self._action_btns.get(tool_id)
            if tool_id in installed:
                lbl.configure(text="Installed — click Open to launch", fg=ACCENT)
                if btn:
                    btn.configure(
                        text="Open",
                        command=lambda tid=tool_id: self.open_tool(tid),
                    )
            else:
                lbl.configure(text="", fg=MUTED)
                if btn:
                    btn.configure(
                        text="Download",
                        command=lambda tid=tool_id: self.download_one(tid),
                    )

    def open_tool(self, tool_id: str) -> None:
        info = self.manifest.get("installed", {}).get(tool_id)
        if not info:
            messagebox.showinfo(self.signature, "Install this tool first.")
            return
        tool_dir = Path(info.get("dir", self.install_root / tool_id))
        launch = find_launchable(tool_dir)
        if not launch:
            # External single-file installs (OSForensics installer)
            for candidate in tool_dir.glob("*"):
                if candidate.is_file() and candidate.suffix.lower() in {".exe", ".msi"}:
                    launch = candidate
                    break
        if not launch:
            messagebox.showwarning(self.signature, f"No executable found in:\n{tool_dir}")
            return
        try:
            os.startfile(str(launch))  # type: ignore[attr-defined]
            self._show_toast(f"Launching {info.get('name', tool_id)}…")
            self.after(1200, self._poll_in_use)
        except OSError as exc:
            messagebox.showerror(self.signature, f"Could not open:\n{launch}\n\n{exc}")

    def download_one(self, tool_id: str) -> None:
        self._run_download([tool_id])

    def download_all(self) -> None:
        ids = [t["id"] for t in self.tools]
        self._run_download(ids)

    def _run_download(self, tool_ids: list[str]) -> None:
        if self.busy:
            return
        self._set_busy(True)

        def worker() -> None:
            total = len(tool_ids)
            for i, tool_id in enumerate(tool_ids):
                tool = next((t for t in self.tools if t["id"] == tool_id), None)
                if not tool:
                    continue
                self.after(0, lambda t=tool: self._set_status(f"Downloading {t['name']}…"))
                try:
                    self._install_tool(tool, i, total)
                except Exception as exc:
                    self.after(
                        0,
                        lambda e=exc, n=tool["name"]: messagebox.showerror(
                            "Download failed", f"{n}\n\n{e}"
                        ),
                    )
            self.after(0, self._finish_download)

        threading.Thread(target=worker, daemon=True).start()

    def _resolve_url(self, tool: dict) -> str:
        if tool.get("source") == "external" and tool.get("downloadUrl"):
            return str(tool["downloadUrl"])
        filename = tool.get("file") or f"{tool['id']}.zip"
        return self.base_url + filename

    def _install_tool(self, tool: dict, index: int, total: int) -> None:
        tool_id = tool["id"]
        filename = tool.get("file") or f"{tool_id}.zip"
        url = self._resolve_url(tool)
        tool_dir = self.install_root / tool_id
        cache_name = Path(filename).name
        zip_path = self.install_root / "_cache" / cache_name

        def on_progress(ratio: float) -> None:
            overall = (index + ratio) / max(total, 1)
            self.after(0, lambda: self._set_status(f"Downloading {tool['name']}…", overall))

        download_file(url, zip_path, on_progress)

        if tool_dir.exists():
            shutil.rmtree(tool_dir, ignore_errors=True)
        tool_dir.mkdir(parents=True, exist_ok=True)

        paths: list[str]
        if zip_path.suffix.lower() == ".zip":
            paths = extract_zip(zip_path, tool_dir)
        else:
            dest = tool_dir / zip_path.name
            shutil.copy2(zip_path, dest)
            paths = [str(dest.resolve())]

        try:
            zip_path.unlink(missing_ok=True)
        except OSError:
            pass

        self.manifest.setdefault("installed", {})[tool_id] = {
            "name": tool["name"],
            "dir": str(tool_dir.resolve()),
            "paths": paths,
            "source": tool.get("source") or "panel",
        }
        save_manifest(self.manifest)

    def _finish_download(self) -> None:
        self._set_busy(False)
        self._set_status("Download complete.", 1.0)
        self._refresh_status()
        messagebox.showinfo(self.signature, "Selected tools were installed.")

    def clean_installed(self) -> None:
        if self.busy:
            return
        installed = self.manifest.get("installed", {})
        if not installed:
            messagebox.showinfo(self.signature, "Nothing installed yet.")
            return
        if self._in_use:
            names = [t["name"] for t in self.tools if t["id"] in self._in_use]
            messagebox.showwarning(
                self.signature,
                "Close these tools before cleaning:\n\n" + "\n".join(names),
            )
            return
        if not messagebox.askyesno(
            "Clean installed tools",
            "Remove ALL tools installed by this panel?\n\nThis deletes every file and folder tracked in the manifest.",
            icon="warning",
        ):
            return

        errors: list[str] = []
        for tool_id, info in list(installed.items()):
            tool_dir = Path(info.get("dir", self.install_root / tool_id))
            try:
                if tool_dir.is_dir():
                    shutil.rmtree(tool_dir, ignore_errors=False)
            except OSError as exc:
                errors.append(f"{info.get('name', tool_id)}: {exc}")

        cache = self.install_root / "_cache"
        if cache.is_dir():
            shutil.rmtree(cache, ignore_errors=True)

        self.manifest = {"installed": {}}
        save_manifest(self.manifest)
        self._refresh_status()
        self._set_status("All panel tools removed.", 0)

        if errors:
            messagebox.showwarning("Clean finished with errors", "\n".join(errors[:8]))
        else:
            messagebox.showinfo(self.signature, "All installed tools were removed.")


def main() -> int:
    try:
        app = FreeToolsPanel()
        app.mainloop()
    except Exception as exc:
        try:
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("dotx Free Tools", f"Panel failed to start:\n\n{exc}")
            root.destroy()
        except Exception:
            print(f"Panel failed to start: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
