# dotx Free Tools Panel

Signature: Free Tools
Product:   dotx Free Tools

## Run (dev)
1. Python 3.12+
2. `python free_tools/panel.py` or `run-free-tools-panel.bat`

## Build EXE
```
python free_tools/build_exe.py
```
Output: `free_tools/dotx-free-tools.exe` (also copied to `web-src/downloads/` and `web/downloads/`)

## Discord badge
Download the panel from the dashboard / tools page while logged in. Your Discord name and avatar are stamped into the upper-right corner of the EXE.

## Features
- Download every listed forensic utility into `%LOCALAPPDATA%\DotXFreeTools\`
- Open installed tools from the panel
- Live **IN USE** badges + toast when a tool process is running (avoids confusing live windows)
- Red **Clean Installed Tools** removes everything the panel installed
- Includes **OSForensics** (official PassMark installer)

Tool ZIPs are served from: https://dotx.store/downloads/free-tools/
OSForensics: https://www.osforensics.com/download.html
