"""Dot X Free Tools — all-in-one panel with download and clean."""
from __future__ import annotations

import json
import os
import shutil
import sys
import threading
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

import tkinter as tk
from tkinter import messagebox, ttk

ROOT = Path(__file__).resolve().parent
CATALOG_PATH = ROOT / "catalog.json"
DEFAULT_BASE_URL = "https://dotx.store/downloads/free-tools/"

# Dot X panel theme
BG = "#0a0e1a"
BG_CARD = "#111827"
BG_HOVER = "#151d30"
TEXT = "#f0f4fa"
MUTED = "#8a94a8"
ACCENT = "#d40000"
ACCENT_SOFT = "#ff4d4d"
TEAL = "#00d4aa"
TEAL_DIM = "#0d9488"
CLEAN_RED = "#dc2626"
CLEAN_RED_HOVER = "#ef4444"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 16, "bold")
FONT_LOGO = ("Segoe UI", 20, "bold")


def app_data_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(base) / "DotXFreeTools"


def manifest_path() -> Path:
    return app_data_dir() / "manifest.json"


def load_catalog() -> dict:
    if CATALOG_PATH.is_file():
        return json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    return {"tools": [], "panelVersion": "1.0.0"}


def load_manifest() -> dict:
    path = manifest_path()
    if not path.is_file():
        return {"installed": {}}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {"installed": {}}


def save_manifest(data: dict) -> None:
    path = manifest_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def download_file(url: str, dest: Path, on_progress=None) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "DotXFreeTools/1.0"})
    with urllib.request.urlopen(req, timeout=120) as resp:
        total = int(resp.headers.get("Content-Length") or 0)
        chunk_size = 65536
        downloaded = 0
        with dest.open("wb") as f:
            while True:
                chunk = resp.read(chunk_size)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                if on_progress and total:
                    on_progress(downloaded / total)


def extract_zip(zip_path: Path, target: Path) -> list[str]:
    target.mkdir(parents=True, exist_ok=True)
    paths: list[str] = []
    with zipfile.ZipFile(zip_path, "r") as zf:
        for member in zf.namelist():
            out = target / member
            zf.extract(member, target)
            paths.append(str(out.resolve()))
    return paths


class FreeToolsPanel(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.catalog = load_catalog()
        self.tools = self.catalog.get("tools", [])
        self.base_url = os.environ.get("DOTX_TOOLS_URL", DEFAULT_BASE_URL).rstrip("/") + "/"
        self.install_root = app_data_dir()
        self.manifest = load_manifest()
        self.check_vars: dict[str, tk.BooleanVar] = {}
        self.busy = False

        self.title("dotx — Free Tools Panel")
        self.geometry("920x640")
        self.minsize(780, 520)
        self.configure(bg=BG)

        self._build_ui()
        self._refresh_status()

    def _build_ui(self) -> None:
        header = tk.Frame(self, bg=BG, padx=20, pady=16)
        header.pack(fill="x")

        logo = tk.Label(
            header,
            text="dot",
            fg=TEXT,
            bg=BG,
            font=FONT_LOGO,
        )
        logo.pack(side="left")
        tk.Label(header, text="x", fg=ACCENT, bg=BG, font=FONT_LOGO).pack(side="left")
        tk.Label(
            header,
            text="  Free Tools Panel",
            fg=MUTED,
            bg=BG,
            font=FONT_TITLE,
        ).pack(side="left", padx=(8, 0))

        tk.Label(
            header,
            text=f"v{self.catalog.get('panelVersion', '1.0')}",
            fg=TEAL_DIM,
            bg=BG,
            font=("Consolas", 9),
        ).pack(side="right")

        sub = tk.Label(
            self,
            text="Download forensic utilities into one folder. Use Clean to remove everything installed from this panel.",
            fg=MUTED,
            bg=BG,
            font=FONT,
            wraplength=860,
            justify="left",
        )
        sub.pack(anchor="w", padx=20, pady=(0, 8))

        toolbar = tk.Frame(self, bg=BG, padx=20, pady=8)
        toolbar.pack(fill="x")

        self.btn_all = tk.Button(
            toolbar,
            text="Download All",
            command=self.download_all,
            bg=TEAL,
            fg=BG,
            activebackground=TEAL_DIM,
            activeforeground=BG,
            relief="flat",
            padx=14,
            pady=6,
            font=FONT_BOLD,
            cursor="hand2",
        )
        self.btn_all.pack(side="left")

        self.btn_sel = tk.Button(
            toolbar,
            text="Download Selected",
            command=self.download_selected,
            bg=BG_CARD,
            fg=TEXT,
            activebackground=BG_HOVER,
            activeforeground=TEXT,
            relief="flat",
            padx=14,
            pady=6,
            font=FONT,
            cursor="hand2",
        )
        self.btn_sel.pack(side="left", padx=(8, 0))

        self.btn_clean = tk.Button(
            toolbar,
            text="Clean Installed Tools",
            command=self.clean_installed,
            bg=CLEAN_RED,
            fg="white",
            activebackground=CLEAN_RED_HOVER,
            activeforeground="white",
            relief="flat",
            padx=14,
            pady=6,
            font=FONT_BOLD,
            cursor="hand2",
        )
        self.btn_clean.pack(side="right")

        path_row = tk.Frame(self, bg=BG, padx=20)
        path_row.pack(fill="x", pady=(4, 8))
        tk.Label(path_row, text="Install folder:", fg=MUTED, bg=BG, font=FONT).pack(side="left")
        tk.Label(path_row, text=str(self.install_root), fg=TEAL, bg=BG, font=("Consolas", 9)).pack(
            side="left", padx=(8, 0)
        )

        list_wrap = tk.Frame(self, bg=BG_CARD, padx=1, pady=1)
        list_wrap.pack(fill="both", expand=True, padx=20, pady=(0, 8))

        canvas = tk.Canvas(list_wrap, bg=BG_CARD, highlightthickness=0)
        scroll = ttk.Scrollbar(list_wrap, orient="vertical", command=canvas.yview)
        self.list_frame = tk.Frame(canvas, bg=BG_CARD)
        self.list_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        canvas.create_window((0, 0), window=self.list_frame, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        for i, tool in enumerate(self.tools):
            self._add_tool_row(self.list_frame, tool, i)

        progress_frame = tk.Frame(self, bg=BG, padx=20, pady=(0, 12))
        progress_frame.pack(fill="x")

        self.progress = ttk.Progressbar(progress_frame, mode="determinate", maximum=100)
        self.progress.pack(fill="x")
        self.status = tk.Label(progress_frame, text="Ready.", fg=MUTED, bg=BG, font=FONT, anchor="w")
        self.status.pack(fill="x", pady=(6, 0))

    def _add_tool_row(self, parent: tk.Frame, tool: dict, index: int) -> None:
        row = tk.Frame(parent, bg=BG_CARD if index % 2 == 0 else BG_HOVER, padx=12, pady=10)
        row.pack(fill="x")

        var = tk.BooleanVar(value=True)
        self.check_vars[tool["id"]] = var
        tk.Checkbutton(
            row,
            variable=var,
            bg=row["bg"],
            activebackground=row["bg"],
            selectcolor=BG,
            highlightthickness=0,
        ).pack(side="left")

        meta = tk.Frame(row, bg=row["bg"])
        meta.pack(side="left", fill="x", expand=True, padx=(8, 0))

        title_row = tk.Frame(meta, bg=row["bg"])
        title_row.pack(fill="x")
        tk.Label(
            title_row,
            text=f"{index + 1:02d}  {tool['name']}",
            fg=TEXT,
            bg=row["bg"],
            font=FONT_BOLD,
        ).pack(side="left")
        tk.Label(
            title_row,
            text=f"  {tool.get('tag', 'Tool')}",
            fg=TEAL,
            bg=row["bg"],
            font=("Consolas", 8),
        ).pack(side="left")

        tk.Label(
            meta,
            text=tool.get("description", ""),
            fg=MUTED,
            bg=row["bg"],
            font=FONT,
            wraplength=720,
            justify="left",
        ).pack(anchor="w", pady=(4, 0))

        self._status_labels = getattr(self, "_status_labels", {})
        status_lbl = tk.Label(row, text="", fg=TEAL_DIM, bg=row["bg"], font=("Consolas", 8), width=12)
        status_lbl.pack(side="right")
        self._status_labels[tool["id"]] = status_lbl

    def _set_busy(self, busy: bool) -> None:
        self.busy = busy
        state = "disabled" if busy else "normal"
        self.btn_all.configure(state=state)
        self.btn_sel.configure(state=state)
        self.btn_clean.configure(state=state)

    def _set_status(self, text: str, pct: float | None = None) -> None:
        self.status.configure(text=text)
        if pct is not None:
            self.progress["value"] = max(0, min(100, pct * 100))

    def _refresh_status(self) -> None:
        installed = self.manifest.get("installed", {})
        for tool_id, lbl in getattr(self, "_status_labels", {}).items():
            if tool_id in installed:
                lbl.configure(text="installed", fg=TEAL)
            else:
                lbl.configure(text="", fg=TEAL_DIM)

    def download_selected(self) -> None:
        ids = [tid for tid, var in self.check_vars.items() if var.get()]
        if not ids:
            messagebox.showinfo("dotx Free Tools", "Select at least one tool.")
            return
        self._run_download(ids)

    def download_all(self) -> None:
        ids = [t["id"] for t in self.tools]
        self._run_download(ids)

    def _run_download(self, tool_ids: list[str]) -> None:
        if self.busy:
            return
        self._set_busy(True)

        def worker() -> None:
            total = len(tool_ids)
            for i, tool_id in enumerate(tool_ids):
                tool = next((t for t in self.tools if t["id"] == tool_id), None)
                if not tool:
                    continue
                self.after(0, lambda t=tool: self._set_status(f"Downloading {t['name']}…"))
                try:
                    self._install_tool(tool, i, total)
                except Exception as exc:
                    self.after(
                        0,
                        lambda e=exc, n=tool["name"]: messagebox.showerror(
                            "Download failed", f"{n}\n\n{e}"
                        ),
                    )
            self.after(0, self._finish_download)

        threading.Thread(target=worker, daemon=True).start()

    def _install_tool(self, tool: dict, index: int, total: int) -> None:
        tool_id = tool["id"]
        filename = tool.get("file") or f"{tool_id}.zip"
        url = self.base_url + filename
        tool_dir = self.install_root / tool_id
        zip_path = self.install_root / "_cache" / filename

        def on_progress(ratio: float) -> None:
            overall = (index + ratio) / max(total, 1)
            self.after(0, lambda: self._set_status(f"Downloading {tool['name']}…", overall))

        download_file(url, zip_path, on_progress)
        paths = extract_zip(zip_path, tool_dir)
        try:
            zip_path.unlink(missing_ok=True)
        except OSError:
            pass

        self.manifest.setdefault("installed", {})[tool_id] = {
            "name": tool["name"],
            "dir": str(tool_dir.resolve()),
            "paths": paths,
        }
        save_manifest(self.manifest)

    def _finish_download(self) -> None:
        self._set_busy(False)
        self._set_status("Download complete.", 1.0)
        self._refresh_status()
        messagebox.showinfo("dotx Free Tools", "Selected tools were installed.")

    def clean_installed(self) -> None:
        if self.busy:
            return
        installed = self.manifest.get("installed", {})
        if not installed:
            messagebox.showinfo("dotx Free Tools", "Nothing installed yet.")
            return
        if not messagebox.askyesno(
            "Clean installed tools",
            "Remove ALL tools installed by this panel?\n\nThis deletes every file and folder tracked in the manifest.",
            icon="warning",
        ):
            return

        errors: list[str] = []
        for tool_id, info in list(installed.items()):
            tool_dir = Path(info.get("dir", self.install_root / tool_id))
            try:
                if tool_dir.is_dir():
                    shutil.rmtree(tool_dir, ignore_errors=False)
            except OSError as exc:
                errors.append(f"{info.get('name', tool_id)}: {exc}")

        cache = self.install_root / "_cache"
        if cache.is_dir():
            shutil.rmtree(cache, ignore_errors=True)

        self.manifest = {"installed": {}}
        save_manifest(self.manifest)
        self._refresh_status()
        self._set_status("All panel tools removed.", 0)

        if errors:
            messagebox.showwarning("Clean finished with errors", "\n".join(errors[:8]))
        else:
            messagebox.showinfo("dotx Free Tools", "All installed tools were removed.")


def main() -> int:
    app = FreeToolsPanel()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
