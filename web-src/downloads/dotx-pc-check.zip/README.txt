dotx PC Check Tool
==================

1. Right-click dotx-pc-check.zip -> Extract All (do NOT open run_scan.bat from inside the zip)
2. Open the extracted folder and double-click run_scan.bat
3. Enter the 6-digit PIN from your dotx staff panel
4. Wait for the scan to finish (Notepad opens with results)

Requires Python 3.10+ installed on the PC.
Download: https://www.python.org/downloads/
Check "Add Python to PATH" during install.
