@echo off
setlocal EnableExtensions
cd /d "%~dp0\.."

set "PYEXE="
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
  set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
)
if not defined PYEXE where py >nul 2>&1 && (
  for /f "delims=" %%I in ('py -3.12 -c "import sys; print(sys.executable)" 2^>nul') do set "PYEXE=%%I"
)
if not defined PYEXE (
  echo [ERROR] Python 3.12 required.
  pause
  exit /b 1
)

"%PYEXE%" free_tools\panel.py
